import java.util.Scanner;

public class No2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Input the number of families: ");
        int numberOfFamilies = scanner.nextInt();

        System.out.print("Input the number of members in the family (separated by a space): ");
        int[] membersFamilie = new int[numberOfFamilies];
        for (int i = 0; i < numberOfFamilies; i++) {
            membersFamilie[i] = scanner.nextInt();
        }

        // Calculate total members
        int totalMembers = 0;
        for (int members : membersFamilie) {
            totalMembers += members;
        }

        // To calculate the number of minibuses required
        int capacityPerBus = 4;
        int busesNeeded = totalMembers / capacityPerBus;
        if (totalMembers % capacityPerBus != 0) {
            busesNeeded++;
        }

        // Output the result
        System.out.println("Minimum bus required is: " + busesNeeded);

        scanner.close();
    }
}
