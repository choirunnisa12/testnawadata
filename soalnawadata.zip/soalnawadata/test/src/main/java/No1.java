import java.util.*;

public class No1 {
    public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Input one line of words (S): ");
            String input = scanner.nextLine().replaceAll("\\s", "").toLowerCase();

            List<Character> vowels = new ArrayList<>();
            List<Character> consonantsCharacters = new ArrayList<>();

            for (char vowelconsonant : input.toCharArray()) {
                if ("aeiou".contains(String.valueOf(vowelconsonant))) {
                    vowels.add(vowelconsonant);
                } else {
                    consonantsCharacters.add(vowelconsonant);
                }
            }

            System.out.println("Vowel Characters:");
            Collections.sort(vowels);
            for (char vow : vowels) {
                System.out.print(vow);
            }

            System.out.println("Consonant Characters:");
            Collections.sort(consonantsCharacters);
            for (char conso : consonantsCharacters) {
                System.out.print(conso);
            }
        }
    }
